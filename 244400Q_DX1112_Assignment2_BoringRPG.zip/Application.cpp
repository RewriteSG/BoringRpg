#include "Application.h"
//#define _CRTDBG_MAP_ALLOC
//#include <stdlib.h>
//#include <crtdbg.h>
#include "Windows.h"

int main(void) 
{
	Application application;
	srand((unsigned int)time(0));
	while (application.GetContinuePgrm())
	{
		application.Start(); 
		application.Update(); 
		application.Exit(); 
	} 
	//_CrtDumpMemoryLeaks();
	return 0;
}

bool Application::GetContinuePgrm() const
{
	return ContinuePgrm;
}

Application::Application() : world(Vector2(1,2)) , objectManager(), gm()
{
	ContinuePgrm = true;
}

void Application::Start()
{
	world.Start();
	objectManager.Start();
	gm.Start();
	world.Render();

}

void Application::Update()
{
	string input = " ";
	while (true) 
	{


		objectManager.UpdateObjects();  // update objects at the start of the frame


		world.Update(objectManager.GetObjects(), objectManager.GetObjectsCount()); // Always call this method before render
		world.Render(objectManager.GetObjects(), objectManager.GetObjectsCount());
		gm.Update();
		if (gm.GetGameEnded())
			break;

		objectManager.UpdateObjectsPosition(); // Update Object positions
		
		gm.PromptInput(); 
		cin >> input;
		LowerString(input);

		gm.HandleInput(input[0]); 

		world.Update(objectManager.GetObjects(), objectManager.GetObjectsCount()); // Always call this method before render  
		world.Render(objectManager.GetObjects(), objectManager.GetObjectsCount());
		

		if(input == "exit")
		break;

	}
}

void Application::Exit()
{
	gm.Exit();
	int objectsCount = objectManager.GetObjectsCount();
	GameObject** Objects = objectManager.GetObjects();
	for (int i = 0; i < objectsCount; i++)
	{
		delete Objects[i];
	}
	delete[] Objects;
	system("cls");
	string EndText = "";
	if (gm.GetGameWon()) 
	{
		EndText = "You Won! Restart Game? Input Yes if you want to Restart";
	}
	else
		EndText = "You Lost! Restart Game? Input Yes if you want to Restart";

	GotoXY(10, 10);
	cout << EndText;
	GotoXY(10, 11);
	cout << "Input : ";
	string input;
	cin >> input;
	LowerString(input);
	ContinuePgrm = (input == "yes");
}

void Application::GotoXY(int x, int y, Vector2 WorldTopLeft)
{

	COORD scrn{};
	HANDLE hConsoleOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	scrn.X = x + WorldTopLeft.GetX();
	scrn.Y = y + WorldTopLeft.GetY();
	SetConsoleCursorPosition(hConsoleOutput, scrn);
}
void Application::GotoXY(int x, int y)
{

	COORD scrn{};
	HANDLE hConsoleOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	scrn.X = x;
	scrn.Y = y;
	SetConsoleCursorPosition(hConsoleOutput, scrn);
}

void Application::LowerString(string& _string)
{
	string result;
	for (char letter : _string) {
		result += tolower(letter);
	}
	_string = result;
}
