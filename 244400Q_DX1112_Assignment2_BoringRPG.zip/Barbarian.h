#pragma once
#include "Player.h"
class Barbarian : public Player
{
public:
    Barbarian();
};

