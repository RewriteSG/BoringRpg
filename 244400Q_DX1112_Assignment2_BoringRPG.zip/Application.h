#pragma once
#include "World.h"
#include "Vector2.h"
#include "ObjectManager.h"
#include "GameManager.h"
#include <iostream>

using namespace std;
class Application
{
	World world;
	ObjectManager objectManager;
	GameManager gm;
	bool ContinuePgrm;
public:
	Application();
	void Start();
	void Update();
	void Exit();
	bool GetContinuePgrm() const;
	static void GotoXY(int x, int y, Vector2 WorldTopLeft) ;
	static void GotoXY(int x, int y);
	static void LowerString(string& _string);
};

