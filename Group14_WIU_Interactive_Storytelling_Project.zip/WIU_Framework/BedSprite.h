#pragma once
#include "Sprite.h"
class BedSprite :
    public Sprite
{

    void Render(int x, int y, Vector2 topLeft) override;

};

