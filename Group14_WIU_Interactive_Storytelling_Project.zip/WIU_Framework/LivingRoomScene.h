#include "Scene.h"


class LivingRoomScene :
    public Scene
{
public:
    LivingRoomScene(void);
    void Start() override;
    void Update() override;
};

