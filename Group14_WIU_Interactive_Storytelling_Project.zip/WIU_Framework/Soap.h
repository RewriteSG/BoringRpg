#pragma once
#include "Items.h"
class Soap :
    public Item
{
public:
	Soap(Vector2 toPos);
};

