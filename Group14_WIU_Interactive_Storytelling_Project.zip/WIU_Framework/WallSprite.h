#pragma once
#include "Sprite.h"
class WallSprite :
    public Sprite
{

        void Render(int x, int y, Vector2 topLeft) override;


};

