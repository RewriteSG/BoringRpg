#pragma once
#include "Scene.h"
class StoreRoomScene :
    public Scene
{

public:
    StoreRoomScene(void);
    void Start() override;
    void Update() override;

};

