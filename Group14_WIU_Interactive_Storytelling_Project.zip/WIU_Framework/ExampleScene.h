#pragma once
#include "Scene.h"
class ExampleScene :
    public Scene
{
public:
    void Start() override;
    void Update() override;
};

