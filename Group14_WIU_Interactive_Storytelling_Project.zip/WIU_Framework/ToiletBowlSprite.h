#pragma once
#include "Sprite.h"
class ToiletBowlSprite :
    public Sprite
{

    void Render(int x, int y, Vector2 topLeft) override;

};

