"W" -move up
"A" -move left
"S" -move down
"D" -move right

"/" to trigger options.
Options:
"e" to enter or exit different rooms through doors.
"I <space> <object name>" or "<object name>" to interact with object.
"use <space> <object name> <space> on <space> <object name>" to  use an object or tool.
   - to use on multiple objects "use <space> <object name> <space> and <space> <object name><space> on <object name>"
"move" to break, and allow player to move again
"wait" special interaction which allows player to wait till ending
"help" to release list of instructions for options.
"Menu" go back to main menu and exit game, will keep progress as long as application is not closed

